"""
MXC Scalp Bot - Telegram Bot Package
"""
from .bot_handler import TelegramBot

__all__ = ['TelegramBot']