"""
MXC Scalp Bot - Config Package
"""
from .settings import Settings

__all__ = ['Settings']