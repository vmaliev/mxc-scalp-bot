"""
MXC Scalp Bot - Web Interface Package
"""
from .web_interface import WebBotController

__all__ = ['WebBotController']