"""
MXC Scalp Trading Bot - Package Initialization
"""